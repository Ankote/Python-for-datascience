# ft_package

A sample Python package with a function to count occurrences of an item in a list.

## Installation

You can install this package by running:

```bash
pip install ./dist/ft_package-0.0.1.tar.gz
```
